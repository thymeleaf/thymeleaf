import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ProcessLog {

    
    public static void main(String[] args) {
        
        try {
            
            final String inputFileName = args[0];
            final int groupSize = Integer.parseInt(args[1]);
            
            final File fileIn = new File(inputFileName);
            final BufferedReader readerIn = new BufferedReader(new FileReader(fileIn));
            
            final Pattern pattern = Pattern.compile("\\[THYMELEAF\\]\\[.*?\\]\\[.*?\\]\\[.*?\\]\\[(.*?)\\]");
            
            String line = null;
            long currentGroup = 0L;
            int currentGroupCount = 0;
            int iteration = 1;
            System.out.println("Iteration;Process Time (nanosecs)");
            while ((line = readerIn.readLine()) != null) {
                final Matcher m = pattern.matcher(line);
                if (m.find()) {
                    final long value = Long.parseLong(m.group(1));
                    currentGroup += value;
                    currentGroupCount++;
                    if (currentGroupCount == groupSize) {
                        System.out.println(iteration + ";" + (currentGroup / groupSize));
                        iteration++;
                        currentGroup = 0L;
                        currentGroupCount = 0;
                    }
                }
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
    }
    
}
