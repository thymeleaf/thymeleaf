#/bin/sh
java ProcessLog $1 1 > "$1.csv"

