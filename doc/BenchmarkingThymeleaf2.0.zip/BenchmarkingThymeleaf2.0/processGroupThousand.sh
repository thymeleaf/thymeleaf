#/bin/sh
java ProcessLog $1 1000 > "$1_group1000.csv"

